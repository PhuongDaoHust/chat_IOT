// import React from 'react'
// import logo from '../assets/images/avatar.png'
// import { FiMoreHorizontal } from 'react-icons/fi'
// import { RiVideoAddFill } from 'react-icons/ri'
// import { AiFillEdit } from 'react-icons/ai'

// const HeaderLeft = () => {
//     const changeTheme = (params) => {

//         document.documentElement.style.setProperty("--background", params)
//     }
//     return (
//         <div className="p-5 flex flex-row items-center space-x-2 border-b border-gray-600" >
//             <img src={logo} className="rounded-full w-10" alt="logo" />
//             <span className="flex-grow font-semibold text-xl">Chats</span>
//             <FiMoreHorizontal className="rounded-full w-8 h-8 p-1 bg-gray-600 hover:bg-gray-700" />
//             <RiVideoAddFill className="rounded-full  w-8 h-8 p-2 bg-gray-600 hover:bg-gray-700" onClick={() => changeTheme("red")} />
//             <AiFillEdit className="rounded-full w-8 h-8 p-1 bg-gray-600 hover:bg-gray-700" onClick={() => changeTheme("#EEE")} />
//         </div>
//     )
// }

// export default HeaderLeft
