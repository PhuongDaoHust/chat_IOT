export const REACT_APP_API_URL =
    process.env.REACT_APP_API_URL ||
    'http://localhost:8000'
export const SOCKET_URL =
    process.env.REACT_APP_API_URL ||
    'http://localhost:8000'
export const VIDEO_CALL_URL =
process.env.VIDEO_CALL_URL ||
'http://localhost:5000'
