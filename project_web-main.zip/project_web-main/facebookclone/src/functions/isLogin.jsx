const isLogin = () => localStorage.getItem('user_id')
export default isLogin
